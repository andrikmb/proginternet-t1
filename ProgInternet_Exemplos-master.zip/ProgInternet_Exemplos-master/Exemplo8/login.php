<!DOCTYPE html>
<html>
	<head>
		<title>Login</title>
		<meta charset="utf-8">
	</head>
	<body>
		<form method="post" action="autentica.php" id="formlogin" name="formlogin" >
			<label>USUÁRIO:</label>
			<input type="text" name="login" id="login"/><br/>
			<label>SENHA:</label>
			<input type="password" name="senha" id="senha"/><br/>
			<input type="submit" value="LOGAR"/>
		</form>
	</body>
</html>

