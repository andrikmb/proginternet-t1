<?php 
class StudentView {
	public function printStudentDetails($studentName, $studentRA){
		print("Estudante: <br>");
		print("Nome: $studentName <br>");
		print("RA: $studentRA <br>");
		
		print("View finalizada.<br><br>");
	}
}

?>