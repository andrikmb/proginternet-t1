<!DOCTYPE html>
<html>
<head>
	<title>Cadastro de Pessoas</title>
	<meta charset="utf-8">
</head>
<body>
<header style="background-color: #c9c9c9">
	<nav><a href="inserir.php" style="float: left; margin-right: 20px">Inserir</a></nav>
	<nav><a href="leitura.php">Consultar</a></nav>
</header>
