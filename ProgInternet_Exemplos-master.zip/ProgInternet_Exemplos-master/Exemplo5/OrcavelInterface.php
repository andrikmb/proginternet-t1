<?php 
interface OrcavelInterface 
{ 
    public function getPreco(); 
}

